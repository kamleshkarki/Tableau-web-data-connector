---
layout: home
---
<!DOCTYPE html>
<html>

<head>
    {% include head.html %}
</head>

<body>
    <div class="container">
        {% include header.html %}
        {{ content }}
        {% include footer.html %}
    </div>
</body>

</html>
